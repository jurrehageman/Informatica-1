import turtle
don = turtle.Turtle()
for step in range(8):
    don.forward(100)
    don.left(45)
