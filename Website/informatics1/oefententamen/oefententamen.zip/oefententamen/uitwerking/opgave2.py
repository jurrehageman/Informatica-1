#!/usr/bin/env python3

print("A")
print("outcome")
print(8888.0//60%60)
print("floor division first")
print(8888.0//60) #148.0
print("Next the remainder \(what is left over after division by 60?\)")
print(148.0%60) #28.0 

#Uitkomst geprint: 1p
#uitleg floor eerst en dan remainder (volgorde): 1p 
#floor division uitgelegd: 1p
#remainder uitgelegd: 1p

#indien uitkomst geprint en uitgelegd dat er een float uitkomt omdat input ook een float is: 2p

print("B")
print("dict", "no order", "key: value pairs") 
print("list", "ordered sequence", "object items") 
#dict geen volgorde: 1p en lijst wel volgorde: 2p
#dict key:value pairs en lijst niet: 2p
#{} ipv []: 2p (syntax)
#keys bij een dict moeten uniek zijn. Er kunnen meerdere gelijke objecten in een lijst staan: 2p

print("C")
print(1 <3) #Python
print(True) #as the integer 1 is smaller than the integer 2
#True: 2p
#1 is smaller than 3: 2p

print("D")
print(1.3 == 0.6 + 0.7)
print("floats are converted to a binairy approximation")
print(0.6 + 0.7) 
print("not 1.3 because 0.6 and 0.7 (floating point numbers) are represented in computer hardware as base 2 (binary) fractions")
#False: 1p
#Uitleg dat floats benaderingen zijn (binaire fracties) in binaire representatie: 3p
#Student moet duidelijk aangeven dat 0.6+0.7 als uitkomst geeft of duidelijk het afrondingsprobleem uitleggen.


print("E")
s = 'tabkcdueflgheijgkl'
print(s[15::-3])
#of
print(s[-3::-3])
#indien eerst string omgedraaid en dan een slice: 1p

print("F")
x **= 5
#gelijk aan:
x = x**5 #dus variabele x wordt overschreven met x to de macht 5: 4p
# ** tot de macht van: 1p
# **5 geeft tot de macht 5 aan: 2p (moet wel juist tot de macht 5 beschreven zijn)
# x wordt overschreven met de nieuwe waarde: 2p


print("G")
#print([1, 2, 3, 4, 5][5]) #gives IndexError
print("index 5 is position 6 (0-based sequence) and does not excist in the list")
# alleen IndexError beschreven maar verder geen uitleg: 2p
# duidelijk de index positie in de lijst omschreven: 4p