#!/usr/bin/env python3
import sys


def read_file(file_name):
    mass = {
    'C':	12.011, 
    'N':	14.007,
    'O':	15.998,
    'P':	30.974,
    'S':	32.065,
    'H':	1.008
    }
    file_obj = open(file_name)
    total_mass = 0
    for line in file_obj:
        line = line.strip()
        if line.startswith("ATOM") or line.startswith("HETATM"):
            total_mass += mass[line[13]]
    file_obj.close()
    return total_mass



def main():
    file_name = sys.argv[1]
    print(file_name)
    total_mass = read_file(file_name)
    print(round(total_mass), 'g/mol')


main()