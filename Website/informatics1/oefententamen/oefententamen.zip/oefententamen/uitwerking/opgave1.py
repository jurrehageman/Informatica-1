#!/usr/bin/env python3 

voornaam = "Jan"
achternaam = "Janssen"

print(voornaam, achternaam)

#punten:
#hashbang: 4p
#voornaam variabele: 3p
#achternaam variabele: 3p
#geprint op scherm: 4p print met concatenatie: 2p
#spatie incorrect maar wel print functie correct: -1p