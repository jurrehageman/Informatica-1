# solution for excersize 01 from Pyhton lecture1

# define a DNA sequence and assign it to a variable
my_dna = "atagcaggagtagccaggag"

# print to screen
print("DNA sequence: ", my_dna)
