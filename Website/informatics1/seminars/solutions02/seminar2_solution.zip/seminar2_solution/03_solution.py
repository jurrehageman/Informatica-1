# solution for excersize 03 from Python lecture1

# define a DNA sequence and assign it to a variable
my_dna = "atagcaggagtagccaggag"
# convert to upper case
my_dna_upper = my_dna.upper()
# reverse string
my_dna_reverse =my_dna_upper[::-1]
# print to screen
print("DNA sequence: ", my_dna_reverse)
