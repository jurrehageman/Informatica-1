first_name = "Jurre"
last_name = "Hageman"

print("Hello", first_name, last_name)
